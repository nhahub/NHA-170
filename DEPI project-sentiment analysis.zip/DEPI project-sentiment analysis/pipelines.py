import pandas as pd
import joblib
import sqlite3
import sys, os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from preprocessing import clean_text

from typing import Optional
import os


# Load model & vectorizer (expects these files to exist in cwd)
MODEL_PATH = os.environ.get('SENTIMENT_MODEL_PATH', 'sentiment_model.pkl')
VECTORIZER_PATH = os.environ.get('TFIDF_VECTORIZER_PATH', 'tfidf_vectorizer.pkl')


def load_assets(model_path: str = MODEL_PATH, vectorizer_path: str = VECTORIZER_PATH):
	model = joblib.load(model_path)
	vectorizer = joblib.load(vectorizer_path)
	return model, vectorizer


def process_new_reviews(new_reviews_path: str = 'new_reviews.csv',
						db_path: str = 'reviews.db',
						model_path: Optional[str] = None,
						vectorizer_path: Optional[str] = None):
	"""Read new reviews, preprocess, predict sentiment, and store results in SQLite.

	Returns the dataframe with predictions.
	"""
	model_path = model_path or MODEL_PATH
	vectorizer_path = vectorizer_path or VECTORIZER_PATH

	model, vectorizer = load_assets(model_path, vectorizer_path)

	new_reviews = pd.read_csv(new_reviews_path)

	# Expect column 'Text' to contain the raw review text
	if 'Text' not in new_reviews.columns:
		raise KeyError("Input CSV must contain a 'Text' column")

	new_reviews['cleaned_review'] = new_reviews['Text'].apply(clean_text)
	X_new = vectorizer.transform(new_reviews['cleaned_review'])
	new_reviews['sentiment'] = model.predict(X_new)

	# Persist
	conn = sqlite3.connect(db_path)
	new_reviews.to_sql('sentiment_reviews', conn, if_exists='append', index=False)
	conn.close()

	return new_reviews


if __name__ == '__main__':
	# Simple CLI behavior when executed directly
	import argparse

	parser = argparse.ArgumentParser(description='Process incoming reviews and store predicted sentiment.')
	parser.add_argument('--input', '-i', default='new_reviews.csv', help='Path to new reviews CSV (must have Text column)')
	parser.add_argument('--db', '-d', default='reviews.db', help='SQLite DB path')
	parser.add_argument('--model', '-m', default=None, help='Path to sentiment model .pkl')
	parser.add_argument('--vectorizer', '-v', default=None, help='Path to tfidf vectorizer .pkl')
	args = parser.parse_args()

	df_out = process_new_reviews(new_reviews_path=args.input, db_path=args.db, model_path=args.model, vectorizer_path=args.vectorizer)
	print(f"Processed {len(df_out)} reviews; stored in {args.db} (table: sentiment_reviews)")
